import React from 'react';
import { AppBar, Toolbar, Typography, TextField, Container } from '@mui/material';
import { useNavigate, Link as RouterLink } from 'react-router-dom';


const Header = () => {
  const navigate = useNavigate();

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      const query = event.target.value;
      if (query) {
        navigate(`/search?query=${encodeURIComponent(query)}`);
      }
    }
  };

  return (
    <AppBar position="sticky">
      <Toolbar>
        <Container style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography
            variant="h6"
            style={{ textDecoration: 'none', color: 'inherit' }}
            component={RouterLink}
            to="/"
          >            Platform Data & IA
          </Typography>
          <TextField
            variant="outlined"
            placeholder="Recherche..."
            size="small"
            style={{ width: '60%', backgroundColor: '#f5f5f5' }}
            onKeyDown={handleKeyDown} 
          />
        </Container>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
