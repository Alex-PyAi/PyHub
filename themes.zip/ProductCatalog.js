import React from 'react';
import { Container, Grid, Typography, Card, CardContent, CardMedia, Button } from '@mui/material';
import storageImage from '../assets/storage.svg';
import aeroImage from '../assets/aero.svg';
import apiImage from '../assets/api.svg';
import excelImage from '../assets/excel.svg';

const products = [
  { id: 1, name: 'Santé', description: 'Visualisation de données avancée', image: storageImage },
  { id: 2, name: 'Aéro', description: 'Modèle de machine learning pré-entraîné', image: aeroImage },
  { id: 3, name: 'API', description: 'Accès aux données', image: apiImage },
  { id: 4, name: 'Excel Eco', description: 'Modèle de machine learning pré-entraîné', image: excelImage },
];

const ProductCatalog = () => {
  return (
    <Container id="catalog" style={{ padding: '50px 0' }}>
      <Typography variant="h3" gutterBottom align="center">
        Data Products
      </Typography>
      <Grid container spacing={4} style={{ margin: '10px auto' }}>
        {products.map((product) => (
          <Grid item key={product.id} xs={12} sm={6} md={4}>
            <Card>
              <CardMedia
                component="img"
                alt={product.name}
                height="200"
                image={product.image}
              />
              <CardContent>
                <Typography gutterBottom variant="h5">
                  {product.name}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  {product.description}
                </Typography>
              </CardContent>
              <Button variant="contained" color="primary" href={`/products/${product.id}`} style={{ margin: '10px 20px' }}>
                En savoir plus
              </Button>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default ProductCatalog;
