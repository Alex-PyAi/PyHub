import React from 'react';
import Header from '../components/Header';
import ProductCatalog from '../components/ProductCatalog';
import Footer from '../components/Footer';

const HomePage = () => {
  return (
    <div>
      <Header />
      <ProductCatalog />
      <Footer />
    </div>
  );
};

export default HomePage;
