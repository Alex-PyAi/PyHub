import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom'; // Utilisation de Link au lieu de RouterLink
import '../static/themes.css'; // Assurez-vous que le fichier CSS est bien importé
 

const Chatbot = () => {

  const [messages, setMessages] = useState([{ text: "Bonjour, comment puis-je aider ?", type: 'bot' }]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const chatContainerRef = useRef(null);

  // scroller en bas du chat
  useEffect(() => {
    chatContainerRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Asyncronous Method : send message
  const sendMessage = async () => {

    const userMessage = input;
    setMessages([...messages, { text: userMessage, type: 'user' }]);
    setInput('');
    setIsTyping(true);

    try {
      let responseMessage = ''; // Variable pour contenir le message de la recherche
      setMessages([...messages, { text: userMessage, type: 'user' }]); // Afficher l'utilisateur dans le chat

      // Poster la requête au serveur avec axios 
      const searchResponse = await axios.post('http://localhost:8000/search', { query: userMessage });
      // Mettre la réponse en forme
      responseMessage = searchResponse.data.results.map((result, index) => (
        <div key={index}>{result}</div>
      ));  

      // Afficher les résultats
      setTimeout(() => {
        setMessages((prevMessages) => [  // Afficher le bot dans le chat
          ...prevMessages,
          { text: (
            <div>
              <div>{responseMessage}</div>
              <Link to={`/search?query=${encodeURIComponent(userMessage)}`}>
                Voir les résultats de recherche
              </Link>
            </div>
          ), type: 'bot' }
        ]);
        setIsTyping(false);
      }, 1000); // Simuler un délai de 1 seconde

    } catch (error) {
      console.error('Erreur:', error);
      setMessages([
        ...messages, 
        { text: userMessage, type: 'user' }, 
        { text: 'Erreur lors de la recherche.', type: 'bot' }
      ]);
      setIsTyping(false);
    }
  };

  return (
    <>
      <div className={`chatbot-container ${isCollapsed ? 'collapsed' : ''}`}>
        <div className="chatbot-header">
          <span>Chatbot</span>
          <button className="chatbot-collapse-button" onClick={() => setIsCollapsed(!isCollapsed)}>
            {isCollapsed ? 'Open' : 'Collapse'}
          </button>
        </div>
        {!isCollapsed && (
          <div className="chatbot-messages" ref={chatContainerRef}>
            {messages.map((msg, index) => (
              <div key={index} className={`chatbot-message ${msg.type}`}>
                {msg.text}
              </div>
            ))}
            {isTyping && <div className="chatbot-message bot typing">...</div>}
          </div>
        )}
        {!isCollapsed && (
          <div className="chatbot-input-container">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              className="chatbot-input"
            />
            <button onClick={sendMessage} className="chatbot-button">
              Envoyer
            </button>
          </div>
        )}
      </div>
      {isCollapsed && (
        <button className="chatbot-expand-button" onClick={() => setIsCollapsed(false)}>
          Open Chat
        </button>
      )}
    </>
  );
};

export default Chatbot;
