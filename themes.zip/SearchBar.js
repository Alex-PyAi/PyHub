import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Autosuggest from 'react-autosuggest';
import { TextField, Container } from '@mui/material';

// Fonction pour gérer les suggestions
const getSuggestions = async (value) => {
  try {
    const response = await axios.get(`http://localhost:8000/suggestions?query=${value}`);
    return response.data.suggestions || [];
  } catch (error) {
    console.error('Erreur lors de la récupération des suggestions:', error);
    return [];
  }
};

const SearchBar = () => {
  const [value, setValue] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [debounceTimeout, setDebounceTimeout] = useState(null);

  const handleSuggestionsFetchRequested = ({ value }) => {
    setInputValue(value);
    if (debounceTimeout) {
      clearTimeout(debounceTimeout);
    }
    const timeout = setTimeout(async () => {
      const suggestions = await getSuggestions(value);
      setSuggestions(suggestions);
    }, 3000); // Attendre 3 secondes avant de récupérer les suggestions
    setDebounceTimeout(timeout);
  };

  const handleSuggestionsClearRequested = () => {
    setSuggestions([]);
  };

  const handleSuggestionSelected = (event, { suggestionValue }) => {
    setValue(suggestionValue);
    // Rediriger vers la page de recherche avec la requête
    window.location.href = `/search?query=${encodeURIComponent(suggestionValue)}`;
  };

  const renderSuggestion = (suggestion) => (
    <div>{suggestion}</div>
  );

  const inputProps = {
    placeholder: 'Recherche...',
    value,
    onChange: (event, { newValue }) => setValue(newValue),
  };

  return (
    <Container style={{ padding: '20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <Autosuggest
        suggestions={suggestions}
        onSuggestionsFetchRequested={handleSuggestionsFetchRequested}
        onSuggestionsClearRequested={handleSuggestionsClearRequested}
        getSuggestionValue={suggestion => suggestion}
        renderSuggestion={renderSuggestion}
        inputProps={inputProps}
        theme={{
          container: 'react-autosuggest__container',
          input: 'react-autosuggest__input',
          suggestionsContainer: 'react-autosuggest__suggestions-container',
          suggestion: 'react-autosuggest__suggestion',
          suggestionHighlighted: 'react-autosuggest__suggestion--highlighted'
        }}
        renderInputComponent={inputProps => (
          <TextField
            variant="outlined"
            size="small"
            style={{ flexGrow: 1, backgroundColor: '#f5f5f5' }}
            {...inputProps}
          />
        )}
      />
    </Container>
  );
};

export default SearchBar;
