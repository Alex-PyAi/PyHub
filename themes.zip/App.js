import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import SearchPage from './pages/SearchPage';
import Chatbot from './components/ChatBot';
import { ChatbotProvider } from './context/ChatbotContext'; // Assurez-vous que ChatbotProvider est défini si utilisé

const App = () => {
  return (
    <ChatbotProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/search" element={<SearchPage />} />
        </Routes>
        <Chatbot /> {/* Chatbot ajouté ici */}
      </Router>
    </ChatbotProvider>
  );
};

export default App;
