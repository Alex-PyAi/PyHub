import React from 'react';
import { Container, Typography, Link } from '@mui/material';

const Footer = () => {
  return (
    <Container style={{ padding: '20px 0', textAlign: 'center', marginTop: '50px' }}>
      <Typography variant="body2" color="textSecondary">
        © 2024 My Data Platform. Tous droits réservés.
      </Typography>
      <Link href="/privacy" color="inherit">
        Politique de confidentialité
      </Link> | 
      <Link href="/terms" color="inherit">
        Conditions d'utilisation
      </Link>
    </Container>
  );
};

export default Footer;
