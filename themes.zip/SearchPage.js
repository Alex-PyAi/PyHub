import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Box, Typography, Slider, Checkbox, FormControlLabel, List, ListItem, ListItemText, CircularProgress, Container, Divider } from '@mui/material';

const SearchPage = () => {
  const [results, setResults] = useState([]);
  const [filters, setFilters] = useState({ category: [], dateRange: [0, 100] });
  const [loading, setLoading] = useState(false);
  const location = useLocation();

  const getQueryParam = () => {
    const queryParams = new URLSearchParams(location.search);
    return queryParams.get('query') || '';
  };

  const fetchResults = async () => {
    setLoading(true);
    const query = getQueryParam();
    if (query) {
      try {
        const response = await axios.post('http://localhost:8000/search', { query, filters });
        setResults(response.data.results || []);
      } catch (error) {
        console.error('Erreur lors de la récupération des résultats:', error);
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchResults();
  }, [location.search, filters]);

  const handleFilterChange = (event) => {
    const { name, value, checked } = event.target;
    setFilters((prevFilters) => {
      const updatedFilters = { ...prevFilters };
      if (name === 'category') {
        updatedFilters.category = checked
          ? [...prevFilters.category, value]
          : prevFilters.category.filter((cat) => cat !== value);
      }
      return updatedFilters;
    });
  };

  const handleSliderChange = (event, newValue) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      dateRange: newValue
    }));
  };

  return (
    <div>
      <Header />
      <Container style={{ display: 'flex', marginTop: '20px' }}>
        <Box width="250px" mr={2} p={2} style={{ borderRight: '1px solid #ddd' }}>
          <Typography variant="h6">Filtres</Typography>
          <Divider style={{ margin: '10px 0' }} />
          <Typography variant="subtitle1">Catégories</Typography>
          <FormControlLabel
            control={<Checkbox name="category" value="eurostat" onChange={handleFilterChange} />}
            label="Eurostat"
          />
          <FormControlLabel
            control={<Checkbox name="category" value="data.gov" onChange={handleFilterChange} />}
            label="Data.gov"
          />
          <FormControlLabel
            control={<Checkbox name="category" value="worldbank" onChange={handleFilterChange} />}
            label="World Bank"
          />
          {/* Ajoutez d'autres filtres ici */}
          <Divider style={{ margin: '20px 0' }} />
          <Typography variant="subtitle1">Date</Typography>
          <Slider
            value={filters.dateRange}
            onChange={handleSliderChange}
            valueLabelDisplay="auto"
            min={0}
            max={100}
            step={1}
          />
        </Box>
        <Box flexGrow={1} p={2}>
          <Typography variant="h4" gutterBottom>Résultats de la Recherche</Typography>
          {loading ? (
            <CircularProgress />
          ) : (
            <div>
              {results.length > 0 ? (
                <List>
                  {results.map((result, index) => (
                    <ListItem key={index}>
                      <ListItemText primary={result} />
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Typography variant="body1">Aucun résultat trouvé.</Typography>
              )}
            </div>
          )}
        </Box>
      </Container>
      <Footer />
    </div>
  );
};

export default SearchPage;
